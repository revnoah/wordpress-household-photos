jQuery(document).ready(function($) {
    console.log('loaded main script');
});
