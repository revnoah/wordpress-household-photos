<div class="alert alert-error">
	<?php	
	foreach ($errors as $error) {
		echo '<p>' . $error . '</p>';
	}
	?>
	</div>

