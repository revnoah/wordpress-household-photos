<div id="household-photos-lightbox" class="lightbox">
    <div class="content">

    </div>
    <div id="lightbox-controls">
        <a href="" class="btn btn-back">Back</a>
        <a href="" class="btn btn-next">Next</a>
    </div>
</div>